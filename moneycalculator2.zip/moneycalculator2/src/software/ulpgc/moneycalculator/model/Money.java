package software.ulpgc.moneycalculator.model;

public record Money(long amount, Currency currency) {
}

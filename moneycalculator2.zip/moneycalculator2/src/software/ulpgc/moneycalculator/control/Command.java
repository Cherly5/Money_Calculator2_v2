package software.ulpgc.moneycalculator.control;

public interface Command {
    void execute();
}

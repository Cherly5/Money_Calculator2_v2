package software.ulpgc.moneycalculator;

import software.ulpgc.moneycalculator.model.Money;

public interface MoneyDisplay {
    void show(Money money);
}
